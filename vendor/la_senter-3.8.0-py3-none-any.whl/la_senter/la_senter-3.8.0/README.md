| Feature | Description |
| --- | --- |
| **Name** | `la_senter` |
| **Version** | `3.8.0` |
| **spaCy** | `>=3.8.3,<3.9.0` |
| **Default Pipeline** | `senter` |
| **Components** | `senter` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | UD_Latin-Perseus<br>UD_Latin-PROIEL<br>UD_Latin-ITTB<br>UD_Latin-LLCT<br>UD_Latin-UDante |
| **License** | `MIT` |
| **Author** | [Patrick J. Burns](https://diyclassics.github.io/) |

### Accuracy

| Type | Score |
| --- | --- |
| `SENTS_F` | 99.62 |
| `SENTS_P` | 99.53 |
| `SENTS_R` | 99.70 |
| `SENTER_LOSS` | 3253.33 |